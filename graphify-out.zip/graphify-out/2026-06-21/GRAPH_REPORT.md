# Graph Report - Trashium  (2026-06-21)

## Corpus Check
- 156 files · ~91,038 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1136 nodes · 1762 edges · 97 communities (56 shown, 41 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 114 edges (avg confidence: 0.88)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `34200458`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_Daily Streaks & Rituals|Daily Streaks & Rituals]]
- [[_COMMUNITY_Crew Telemetry & Route Mapping|Crew Telemetry & Route Mapping]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_SVG Brand & Icon Assets|SVG Brand & Icon Assets]]
- [[_COMMUNITY_Crew Telemetry & Route Mapping|Crew Telemetry & Route Mapping]]
- [[_COMMUNITY_Pricing & Estimator Engine|Pricing & Estimator Engine]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_package.json & Related Modules|package.json & Related Modules]]
- [[_COMMUNITY_SVG Brand & Icon Assets|SVG Brand & Icon Assets]]
- [[_COMMUNITY_Pricing & Estimator Engine|Pricing & Estimator Engine]]
- [[_COMMUNITY_SVG Brand & Icon Assets|SVG Brand & Icon Assets]]
- [[_COMMUNITY_Crew Telemetry & Route Mapping|Crew Telemetry & Route Mapping]]
- [[_COMMUNITY_tsconfig.json & Related Modules|tsconfig.json & Related Modules]]
- [[_COMMUNITY_tsconfig.json & Related Modules|tsconfig.json & Related Modules]]
- [[_COMMUNITY_Eco Levels & Gamification Badges|Eco Levels & Gamification Badges]]
- [[_COMMUNITY_Daily Streaks & Rituals|Daily Streaks & Rituals]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_Crew Telemetry & Route Mapping|Crew Telemetry & Route Mapping]]
- [[_COMMUNITY_Daily Streaks & Rituals|Daily Streaks & Rituals]]
- [[_COMMUNITY_Eco Levels & Gamification Badges|Eco Levels & Gamification Badges]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_cormorant & Related Modules|cormorant & Related Modules]]
- [[_COMMUNITY_ML Pricing Service & Models|ML Pricing Service & Models]]
- [[_COMMUNITY_Pricing & Estimator Engine|Pricing & Estimator Engine]]
- [[_COMMUNITY_ML Pricing Service & Models|ML Pricing Service & Models]]
- [[_COMMUNITY_SVG Brand & Icon Assets|SVG Brand & Icon Assets]]
- [[_COMMUNITY_SVG Brand & Icon Assets|SVG Brand & Icon Assets]]
- [[_COMMUNITY_Daily Streaks & Rituals|Daily Streaks & Rituals]]
- [[_COMMUNITY_Marketplace Perk Redemptions|Marketplace Perk Redemptions]]
- [[_COMMUNITY_Admin Hub & Management|Admin Hub & Management]]
- [[_COMMUNITY_Crew Telemetry & Route Mapping|Crew Telemetry & Route Mapping]]
- [[_COMMUNITY_Eco Levels & Gamification Badges|Eco Levels & Gamification Badges]]
- [[_COMMUNITY_Eco Levels & Gamification Badges|Eco Levels & Gamification Badges]]
- [[_COMMUNITY_Pricing & Estimator Engine|Pricing & Estimator Engine]]
- [[_COMMUNITY_geistMono & Related Modules|geistMono & Related Modules]]
- [[_COMMUNITY_Next.js Agent Rules & Related Modules|Next.js Agent Rules & Related Modules]]
- [[_COMMUNITY_README.md & Related Modules|README.md & Related Modules]]
- [[_COMMUNITY_ML Pricing Service & Models|ML Pricing Service & Models]]
- [[_COMMUNITY_AGENTS.md & Related Modules|AGENTS.md & Related Modules]]
- [[_COMMUNITY_ML Pricing Service & Models|ML Pricing Service & Models]]
- [[_COMMUNITY_postcss.config.mjs & Related Modules|postcss.config.mjs & Related Modules]]
- [[_COMMUNITY_eslint.config.mjs & Related Modules|eslint.config.mjs & Related Modules]]
- [[_COMMUNITY_next.config.ts & Related Modules|next.config.ts & Related Modules]]
- [[_COMMUNITY_postcss.config.mjs & Related Modules|postcss.config.mjs & Related Modules]]
- [[_COMMUNITY_ML API Local Requirements|ML API Local Requirements]]
- [[_COMMUNITY_App Icon SVG|App Icon SVG]]
- [[_COMMUNITY_RootLayout|RootLayout]]
- [[_COMMUNITY_Loading|Loading]]
- [[_COMMUNITY_next.config.ts — Next.js Config|next.config.ts — Next.js Config]]
- [[_COMMUNITY_trashium-apppackage.json|trashium-app/package.json]]
- [[_COMMUNITY_Trashium Favicon SVG|Trashium Favicon SVG]]
- [[_COMMUNITY_Trashium Icon Static SVG|Trashium Icon Static SVG]]
- [[_COMMUNITY_Trashium Animated Logo|Trashium Animated Logo]]
- [[_COMMUNITY_Trashium Static Logo|Trashium Static Logo]]
- [[_COMMUNITY_Trashium Wordmark Logo|Trashium Wordmark Logo]]
- [[_COMMUNITY_.claudesettings.local.json|.claude/settings.local.json]]
- [[_COMMUNITY_.codexhooks.json - Impeccable Design Detector Hook|.codex/hooks.json - Impeccable Design Detector Hook]]
- [[_COMMUNITY_ShadcnUI Components Configuration|Shadcn/UI Components Configuration]]
- [[_COMMUNITY_handleLaunchQuiz|handleLaunchQuiz]]
- [[_COMMUNITY_handleReschedulePickup|handleReschedulePickup]]
- [[_COMMUNITY_RLS Disabled on New Tables (Decision D3)|RLS Disabled on New Tables (Decision D3)]]
- [[_COMMUNITY_Graphify Markdown|Graphify Markdown]]
- [[_COMMUNITY_OperationalSector|OperationalSector]]
- [[_COMMUNITY_DemandLevel|DemandLevel]]
- [[_COMMUNITY_getTierByRank|getTierByRank]]
- [[_COMMUNITY_Tier|Tier]]
- [[_COMMUNITY_LatLng|LatLng]]
- [[_COMMUNITY_estimateLogisticsCost|estimateLogisticsCost]]
- [[_COMMUNITY_LatLng|LatLng]]
- [[_COMMUNITY_logisticsPerKg|logisticsPerKg]]
- [[_COMMUNITY_marginPerKg|marginPerKg]]
- [[_COMMUNITY_userPayoutPerKg|userPayoutPerKg]]
- [[_COMMUNITY_haversineKm|haversineKm]]
- [[_COMMUNITY_OptimizedRoute|OptimizedRoute]]
- [[_COMMUNITY_TruckConstraints|TruckConstraints]]
- [[_COMMUNITY_REGION_TO_SECTOR Mapping|REGION_TO_SECTOR Mapping]]
- [[_COMMUNITY_proxy|proxy]]
- [[_COMMUNITY_File Icon SVG|File Icon SVG]]
- [[_COMMUNITY_Globe Icon SVG|Globe Icon SVG]]
- [[_COMMUNITY_Window  Browser Icon SVG|Window / Browser Icon SVG]]
- [[_COMMUNITY_README.md Documentation|README.md Documentation]]
- [[_COMMUNITY_Root package.json (trashium)|Root package.json (trashium)]]
- [[_COMMUNITY_Agent Rules|Agent Rules]]
- [[_COMMUNITY_LoaderEstimatorAdmin Handoff (2026-06-19)|Loader/Estimator/Admin Handoff (2026-06-19)]]
- [[_COMMUNITY_Trashium package.json|Trashium package.json]]
- [[_COMMUNITY_KineticTypographyLoaderProps|KineticTypographyLoaderProps]]
- [[_COMMUNITY_ML v2 Scratch Folder README|ML v2 Scratch Folder README]]

## God Nodes (most connected - your core abstractions)
1. `createClient()` - 27 edges
2. `createClient()` - 22 edges
3. `Button()` - 19 edges
4. `CrewDashboardContent()` - 18 edges
5. `DashboardContent()` - 18 edges
6. `Trashium Pricing ML — Project Context & Session Handoff` - 18 edges
7. `compilerOptions` - 16 edges
8. `compilerOptions` - 16 edges
9. `Trashium — Marketplace + Badge System Implementation Plan [COMPLETED]` - 15 edges
10. `MarketplaceAdmin()` - 14 edges

## Surprising Connections (you probably didn't know these)
- `Marketplace Access Gate (500 credits + 1 pickup)` --conceptually_related_to--> `MarketplaceItem`  [INFERRED]
  MARKETPLACE_IMPLEMENTATION_PLAN.md → lib/types.ts
- `Admin Hub Monitoring Plan` --rationale_for--> `AdminContent()`  [INFERRED]
  ADMIN_HUB_MONITORING_PLAN.md → app/admin/admin-content.tsx
- `MarketplaceAdmin()` --semantically_similar_to--> `MarketplaceContent()`  [INFERRED] [semantically similar]
  components/admin/marketplace-admin.tsx → app/marketplace/marketplace-content.tsx
- `Admin Hub Monitoring Plan` --references--> `MarketplaceAdmin()`  [INFERRED]
  ADMIN_HUB_MONITORING_PLAN.md → components/admin/marketplace-admin.tsx
- `Marketplace + Badge System Implementation Plan` --references--> `evaluateBadges()`  [INFERRED]
  MARKETPLACE_IMPLEMENTATION_PLAN.md → lib/badges.ts

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **GPS Telemetry Broadcast → Track Flow** — crew_crew_content_crewdashboardcontent, tracking_tracking_content_trackingcontent, tracking_tracking_map_trackingmap, concept_realtime_telemetry_broadcast [EXTRACTED 0.95]
- **Pickup Request Lifecycle (Schedule → Crew → Admin)** — dashboard_dashboard_content_dashboardcontent, crew_crew_content_crewdashboardcontent, admin_admin_content_admincontent, concept_sector_based_operations [INFERRED 0.85]
- **Boneyard Skeleton Loading System** — boneyard_config, admin_loading_adminloading, crew_loading_crewloading, dashboard_loading_dashboardloading, marketplace_loading_marketplaceloading, profile_loading_profileloading [EXTRACTED 0.95]
- **** — admin_payout_override, admin_price_grid, dashboard_schedule_pickup_modal, materials_flipping_rates [INFERRED 0.85]
- **** — dashboard_eco_level_badge, ui_daily_ritual, ui_leaderboard_podium, admin_marketplace_admin [INFERRED 0.85]
- **** — admin_crew_hub_assignment, maps_crewroutemap, maps_optimizedroutemap [INFERRED 0.85]
- **** — lib_estimate, lib_pricing_math, lib_pricing_constants, lib_estimator_types, ml_api_main, lib_waste_items [EXTRACTED 1.00]
- **** — ui_streak_card, ui_streak_calendar, migrations_0005_daily_ritual, lib_types [INFERRED 0.95]
- **** — lib_route_optimizer, lib_osrm, lib_constants [INFERRED 0.85]

## Communities (97 total, 41 thin omitted)

### Community 0 - "Admin Hub & Management"
Cohesion: 0.17
Nodes (19): BadgeCategory, BadgeUnlockType, DailyActionResult, ECO_LEVELS, EcoLevel, EcoLevelName, getEcoLevel(), getNextEcoLevel() (+11 more)

### Community 1 - "Daily Streaks & Rituals"
Cohesion: 0.05
Nodes (44): Daily Streak & Gamification System, S: Drive Disk Corruption Issue, Radix UI vs Base UI API Mixin Problem, Debugging Session Handoff Notes, Marketplace Implementation Plan, DailyRitual(), DailyRitualProps, MILESTONES (+36 more)

### Community 2 - "Crew Telemetry & Route Mapping"
Cohesion: 0.08
Nodes (35): AdminOrder, emptyForm, FormState, ORDER_STATUSES, TIERS, OPERATIONAL_SECTORS, SchedulePickupModalProps, TRASHIUM_PICKUP_SLOTS (+27 more)

### Community 3 - "Admin Hub & Management"
Cohesion: 0.06
Nodes (23): AdminOrder, getDisplayWeight(), Pickup Lifecycle, getDisplayWeight(), TRASHIUM_PICKUP_SLOTS, Badge(), badgeVariants, DropdownMenu() (+15 more)

### Community 4 - "SVG Brand & Icon Assets"
Cohesion: 0.05
Nodes (42): eslintConfig, dependencies, @base-ui/react, boneyard-js, class-variance-authority, clsx, leaflet, lucide-react (+34 more)

### Community 5 - "Crew Telemetry & Route Mapping"
Cohesion: 0.07
Nodes (29): AdminPage(), HomePage(), CrewDashboardPage(), features, HeroSection(), HowItWorks(), steps, ImpactCounter() (+21 more)

### Community 6 - "Pricing & Estimator Engine"
Cohesion: 0.06
Nodes (41): ML Model Metrics (v2), ML Model Metrics v2 (duplicate), Price Estimates Seed SQL, ColumnTransformer, build(), DataFrame, Bridge the market-value model to the Trashium app price table.  Steps:   1. Pred, to_sql() (+33 more)

### Community 7 - "Admin Hub & Management"
Cohesion: 0.16
Nodes (15): Real-time GPS Telemetry via Supabase Broadcast, Real-time GPS Telemetry Broadcast, Supabase Realtime Broadcast Telemetry Channel, Shared Estimator Contract (estimateQuote), CrewDashboardContent(), getCalculatedPayout, GPS Telemetry Broadcast Channel, GPS Telemetry Broadcast (useEffect) (+7 more)

### Community 8 - "Admin Hub & Management"
Cohesion: 0.06
Nodes (59): PayoutOverride(), RISKS, Inference API Readme, ML API Requirements, Marketplace Perk - Payout Boost (pending_payout_boost_pct), Pricing Engine, Pricing Pipeline (model → table → fallback), CREW_SECTORS (+51 more)

### Community 9 - "package.json & Related Modules"
Cohesion: 0.08
Nodes (25): dependencies, clsx, motion, next, react, react-dom, tailwind-merge, @tailwindcss/cli (+17 more)

### Community 10 - "SVG Brand & Icon Assets"
Cohesion: 0.08
Nodes (23): aliases, components, hooks, lib, ui, utils, iconLibrary, menuAccent (+15 more)

### Community 11 - "Pricing & Estimator Engine"
Cohesion: 0.08
Nodes (24): Agent / AI Coding Rules, Authentication & Role System, `badges` / `user_badges`  *(gamification)*, Color Palette, Component Conventions, `daily_activity` / `streak_milestone_claims` *(daily streaks & rituals)*, Database Schema (Supabase Postgres), Environment Variables (+16 more)

### Community 12 - "SVG Brand & Icon Assets"
Cohesion: 0.16
Nodes (20): fetchRoleWithRetry, handleLogout, Navbar(), Role-Aware Navigation Items, MobileNav(), MobileNavHeader(), MobileNavHeaderProps, MobileNavMenu() (+12 more)

### Community 13 - "Crew Telemetry & Route Mapping"
Cohesion: 0.09
Nodes (22): 10. File map (`ml/`), 11. How to run, 12. Verification status (all passing), 13. Limitations & next steps, 14. Environment constraints & gotchas (for whoever continues), 15. Key constants (quick reference), 16. Session log (what we did, in order), 1. Project overview (+14 more)

### Community 14 - "tsconfig.json & Related Modules"
Cohesion: 0.10
Nodes (20): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+12 more)

### Community 15 - "tsconfig.json & Related Modules"
Cohesion: 0.10
Nodes (19): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+11 more)

### Community 16 - "Eco Levels & Gamification Badges"
Cohesion: 0.07
Nodes (26): 0. Decisions locked with the user (do not re-litigate), 10. Verification (MANDATORY — native, per the S: drive warning), 11. Guardrails (house rules — do not break), 1. The v2 ML serving contract (the spec we are matching), 2. Current state — what exists today, 2a. `price_estimates` table (live Supabase, project `fqbjjcbrxrokvdwkydze`), 2b. `lib/pricing.ts` (server) + `lib/pricing-math.ts` (client), 2c. Household estimator — `components/dashboard/schedule-pickup-modal.tsx` (+18 more)

### Community 17 - "Daily Streaks & Rituals"
Cohesion: 0.09
Nodes (28): Achievement, AchievementBadge, AchievementBadgeProps, badgeSizeMap, iconSizeMap, progressRingSizeMap, UserAchievement, Achievement (+20 more)

### Community 18 - "Admin Hub & Management"
Cohesion: 0.14
Nodes (16): normalizeSectorName(), DashboardContentProps, DEFAULT_DAILY, handleSubmitQuiz, normalizePickup(), normalizeSectorName(), OPERATIONAL_SECTORS, DashboardPage() (+8 more)

### Community 19 - "Crew Telemetry & Route Mapping"
Cohesion: 0.07
Nodes (39): CLAUDE.md — AI Agent Guide, build_price_table.py — Rate Table Generator, Commission Lever for Trashium Profit (c=0.15), config.py — Business Knobs & Schema, Dataset Regeneration for Learnable Risk & Demand, dataset_learnable.xlsx — Canonical Training File, Dataset Demand/Risk Signal Correction, Eco Gamification System (Credits, Levels) (+31 more)

### Community 20 - "Daily Streaks & Rituals"
Cohesion: 0.11
Nodes (26): 20-Tier Eco-Level System (TRASHIUM_EVALUATION_TIERS), Daily Ritual Gamification System, Green Credits - Gamification Currency, Marketplace Access Gate (500 credits + 1 pickup), DashboardContent(), getSectorRankings, handleCancelPickup, handleLogWasteSegregation (+18 more)

### Community 21 - "Eco Levels & Gamification Badges"
Cohesion: 0.14
Nodes (10): PointsLevelList, pointsLevelListIconMap, PointsLevelListIconType, PointsLevelsList, PointsLevelsListProps, PointsSubLevelList, PointsLevelsTimeline, PointsLevelsTimelineProps (+2 more)

### Community 22 - "Admin Hub & Management"
Cohesion: 0.20
Nodes (8): Crew Operations, Operational Sectors (West Bengal Regions), ChangeMapCenter, CrewRouteMap(), defaultIcon, RouteMapProps, SECTOR_COORDINATES, vehicleIcon

### Community 23 - "cormorant & Related Modules"
Cohesion: 0.08
Nodes (27): Crew, CrewHubAssignment(), cormorant, dmSans, jetbrainsMono, syne, metadata, OPERATIONAL_SECTORS (+19 more)

### Community 26 - "ML Pricing Service & Models"
Cohesion: 0.08
Nodes (23): 1. Features Implemented, 1. Kinetic Typography Loader — DONE & wired, 2. Current State & Verification, 2. Price Estimator Rehaul — built by VS Code extension, verified by us, 3. Admin Monitoring + Payout Override Hub — built by extension, verified by us, 3. Next Steps & Phase 2 Action Items, 4. Per-Stop Logistics Fix — DONE this session (fixes the crew ₹0), 5. PostgREST embed bug — FIXED this session (+15 more)

### Community 27 - "SVG Brand & Icon Assets"
Cohesion: 0.20
Nodes (7): iconMap, ImpactCard(), ImpactCardProps, Card(), CardContent(), CardHeader(), CardTitle()

### Community 28 - "SVG Brand & Icon Assets"
Cohesion: 0.50
Nodes (4): Next.js Agent Rules (Breaking Changes Warning), Trashium Next.js Web Application, Next.js Logo SVG, Vercel Logo SVG (Triangle)

### Community 29 - "Daily Streaks & Rituals"
Cohesion: 0.09
Nodes (22): 0. How to use this document (agent instructions), 1. Confirmed product decisions (do not re-litigate), 2. Current-state findings (already verified — trust these, don't re-derive), 3. Image handling (applies to badges AND marketplace items), 4. Out of scope (Phase 2 — do NOT build now), 5. [ASK USER] checkpoints, B-1. Schema (apply via MCP; mirror in `supabase_schema.sql`; NO RLS yet), B-2. Computation logic (+14 more)

### Community 30 - "Marketplace Perk Redemptions"
Cohesion: 0.13
Nodes (16): CountUp(), CountUpProps, LeaderboardCard, LeaderboardCardProps, LeaderboardRunOption, LeaderboardPodium, LeaderboardPodiumProps, LeaderboardRanking (+8 more)

### Community 31 - "Admin Hub & Management"
Cohesion: 0.08
Nodes (7): AdminLoading(), Boneyard Config (Skeleton Loading), Boneyard Skeleton Loading Pattern, CrewLoading(), DashboardLoading(), MarketplaceLoading(), ProfileLoading()

### Community 32 - "Crew Telemetry & Route Mapping"
Cohesion: 0.25
Nodes (7): Business formulas (single source of truth: `pricing.py`), Data corrections (`regenerate_dataset.py`), How it maps to the app, Real recycler price feed (optional override), Run the pipeline, Trashium Pricing ML (v2 — market-value model), What the models predict

### Community 33 - "Eco Levels & Gamification Badges"
Cohesion: 0.11
Nodes (18): 1.1 What the model actually consumes, 1.2 How user payout is derived (`ml/pricing.py`, locked formula), 1.3 The three tables — what each needs, 1. Input / Output Analysis, 2. Avoid Waste-Type Squashing — the 20 materials, 3.1 `config.py` — add a material→bucket map (keep the category map for fallback), 3.2 `data_prep.py` — add the leaf→bucket column (no feature change), 3.3 `build_price_table.py` — group by material, not by bucket (+10 more)

### Community 35 - "Eco Levels & Gamification Badges"
Cohesion: 0.29
Nodes (3): PointsChartDataPoint, PointsChartLevel, PointsChartProps

### Community 37 - "geistMono & Related Modules"
Cohesion: 0.40
Nodes (3): geistMono, geistSans, metadata

### Community 38 - "Next.js Agent Rules & Related Modules"
Cohesion: 0.50
Nodes (3): Next.js Agent Rules, CLAUDE.md Documentation, nextConfig

### Community 39 - "README.md & Related Modules"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

### Community 54 - "Loading"
Cohesion: 0.14
Nodes (16): AdminContentProps, award (badge award function), MarketplaceAdmin(), Props, saveItem, updateOrderStatus (MarketplaceAdmin), metadata, Gamification System (+8 more)

### Community 69 - "OperationalSector"
Cohesion: 0.12
Nodes (16): 0. Key finding — the admin hub is NOT empty (correct the mental model first), 10. ML model seam — keep the estimator drop-in ready (do NOT break this), 1. Decisions locked with the user, 2. Surface-by-surface plan, 3. Schema + backend (for the persisted override), 4. Icon, 5. Replace the mock analytics with real aggregates, 6. UI / UX (use `/frontend-design`, stay in the existing system) (+8 more)

### Community 70 - "DemandLevel"
Cohesion: 0.24
Nodes (13): Phase 2 Badge Locks (streak/referral/quiz), badgeCurrent(), BadgeSignals, evaluateBadges(), isBadgeUnlocked(), KG_BADGE_MATERIAL, MEASURABLE, ProfileLike (+5 more)

### Community 71 - "getTierByRank"
Cohesion: 0.33
Nodes (10): _auth(), BatchIn, predict(), predict_batch(), PredictIn, PredictOut, Trashium pricing model — live inference service (FastAPI).  WHY THIS EXISTS   sc, Enforce the shared bearer token when API_TOKEN is configured (no-op otherwise). (+2 more)

### Community 72 - "Tier"
Cohesion: 0.17
Nodes (11): Connect Next.js (Vercel env vars), Deploy, Docker (any host), Endpoints, Fly.io, Railway (simplest), Render, Run locally (+3 more)

### Community 73 - "LatLng"
Cohesion: 0.28
Nodes (5): fetchOsrmRoute(), LatLng, RouteStop, depotIcon, Props

### Community 74 - "estimateLogisticsCost"
Cohesion: 0.18
Nodes (10): 0. The diagnosis (why ₹0 happens — confirmed, not a bug), 1. The fix — allocate logistics per stop, not per household-as-sole-trip, 2. Files to change (small, surgical — model seam untouched), 3. Optional polish (only if you want it), 4. Verification (native, per the S: drive corruption warning), 5. One-line summary for the build, EDIT — `lib/pricing-constants.ts`, EDIT — `lib/pricing-math.ts` (+2 more)

### Community 75 - "LatLng"
Cohesion: 0.25
Nodes (8): AdminContent(), fetchFullFledgedData, getSectorRankings, handleExportSectorSummary, handleStatusUpdate, isTimeDiscrepancy, Sector-Based Operations Model, Sector-based Leaderboard System

### Community 76 - "logisticsPerKg"
Cohesion: 0.29
Nodes (6): Dual Balance Credit Tradeoff (D1), Badges — bucket: `gamification-badges`, Daily Grove Ritual & Streaks — Vector Assets, Image Manifest — Badges & Marketplace, Marketplace items — bucket: `marketplace-items`, Marketplace + Badge System Implementation Plan

### Community 78 - "userPayoutPerKg"
Cohesion: 0.40
Nodes (4): homeIcon, TrackingMap(), TrackingMapProps, truckIcon

### Community 79 - "haversineKm"
Cohesion: 0.43
Nodes (6): Client-Side Route Optimization (NN + 2-opt), haversineKm(), OptimizedRoute, optimizeRoute(), routeDistance(), TruckConstraints

### Community 80 - "OptimizedRoute"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

## Knowledge Gaps
- **485 isolated node(s):** `AdminOrder`, `metadata`, `OptimizedRouteMap`, `CREW_SECTORS`, `CrewDashboardProps` (+480 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **41 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `createClient()` connect `cormorant & Related Modules` to `Crew Telemetry & Route Mapping`, `Admin Hub & Management`, `Crew Telemetry & Route Mapping`, `Admin Hub & Management`, `Admin Hub & Management`, `LatLng`, `SVG Brand & Icon Assets`, `Admin Hub & Management`, `Daily Streaks & Rituals`, `Loading`?**
  _High betweenness centrality (0.045) - this node is a cross-community bridge._
- **Why does `price_estimates Supabase Table` connect `Crew Telemetry & Route Mapping` to `Crew Telemetry & Route Mapping`, `Pricing & Estimator Engine`?**
  _High betweenness centrality (0.040) - this node is a cross-community bridge._
- **Why does `getRate()` connect `Crew Telemetry & Route Mapping` to `Admin Hub & Management`, `Crew Telemetry & Route Mapping`?**
  _High betweenness centrality (0.033) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `createClient()` (e.g. with `createClient()` and `updateSession()`) actually correct?**
  _`createClient()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **Are the 2 inferred relationships involving `CrewDashboardContent()` (e.g. with `AdminContent()` and `Real-time GPS Telemetry via Supabase Broadcast`) actually correct?**
  _`CrewDashboardContent()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `AdminOrder`, `metadata`, `OptimizedRouteMap` to the rest of the system?**
  _519 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Daily Streaks & Rituals` be split into smaller, more focused modules?**
  _Cohesion score 0.05454545454545454 - nodes in this community are weakly interconnected._