# Graph Report - .  (2026-06-21)

## Corpus Check
- 32 files · ~100,975 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1197 nodes · 1862 edges · 105 communities (63 shown, 42 thin omitted)
- Extraction: 94% EXTRACTED · 6% INFERRED · 0% AMBIGUOUS · INFERRED: 114 edges (avg confidence: 0.88)
- Token cost: 0 input · 0 output

## Community Hubs (Navigation)
- [[_COMMUNITY_Admin Marketplace & Catalog Control|Admin Marketplace & Catalog Control]]
- [[_COMMUNITY_Admin Payout Overrides & Crew Hub|Admin Payout Overrides & Crew Hub]]
- [[_COMMUNITY_Admin Hub & Layout UI Core|Admin Hub & Layout UI Core]]
- [[_COMMUNITY_Daily Streak & Gamification System|Daily Streak & Gamification System]]
- [[_COMMUNITY_GPS Telemetry & Pickup Dispatch|GPS Telemetry & Pickup Dispatch]]
- [[_COMMUNITY_ML Price Modeling & Pipeline|ML Price Modeling & Pipeline]]
- [[_COMMUNITY_Project Configuration & Dependencies|Project Configuration & Dependencies]]
- [[_COMMUNITY_Corporate Info & Policy Pages|Corporate Info & Policy Pages]]
- [[_COMMUNITY_Achievements & Badges UI|Achievements & Badges UI]]
- [[_COMMUNITY_Admin Implementation Planning|Admin Implementation Planning]]
- [[_COMMUNITY_Community 10|Community 10]]
- [[_COMMUNITY_Community 11|Community 11]]
- [[_COMMUNITY_Community 12|Community 12]]
- [[_COMMUNITY_Community 13|Community 13]]
- [[_COMMUNITY_Community 14|Community 14]]
- [[_COMMUNITY_Community 15|Community 15]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 18|Community 18]]
- [[_COMMUNITY_Community 19|Community 19]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 46|Community 46]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 48|Community 48]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]
- [[_COMMUNITY_Community 84|Community 84]]
- [[_COMMUNITY_Community 85|Community 85]]
- [[_COMMUNITY_Community 86|Community 86]]
- [[_COMMUNITY_Community 87|Community 87]]
- [[_COMMUNITY_Community 88|Community 88]]
- [[_COMMUNITY_Community 89|Community 89]]
- [[_COMMUNITY_Community 90|Community 90]]
- [[_COMMUNITY_Community 91|Community 91]]
- [[_COMMUNITY_Community 92|Community 92]]
- [[_COMMUNITY_Community 94|Community 94]]
- [[_COMMUNITY_Community 95|Community 95]]
- [[_COMMUNITY_Community 96|Community 96]]
- [[_COMMUNITY_Community 97|Community 97]]
- [[_COMMUNITY_Community 98|Community 98]]
- [[_COMMUNITY_Community 100|Community 100]]
- [[_COMMUNITY_Community 102|Community 102]]
- [[_COMMUNITY_Community 103|Community 103]]
- [[_COMMUNITY_Community 104|Community 104]]

## God Nodes (most connected - your core abstractions)
1. `createClient()` - 27 edges
2. `createClient()` - 23 edges
3. `Button()` - 19 edges
4. `CrewDashboardContent()` - 18 edges
5. `DashboardContent()` - 18 edges
6. `Trashium Pricing ML — Project Context & Session Handoff` - 18 edges
7. `compilerOptions` - 16 edges
8. `compilerOptions` - 16 edges
9. `Trashium — Marketplace + Badge System Implementation Plan [COMPLETED]` - 15 edges
10. `MarketplaceAdmin()` - 14 edges

## Surprising Connections (you probably didn't know these)
- `Marketplace Access Gate (500 credits + 1 pickup)` --conceptually_related_to--> `MarketplaceItem`  [INFERRED]
  MARKETPLACE_IMPLEMENTATION_PLAN.md → lib/types.ts
- `Admin Hub Monitoring Plan` --rationale_for--> `AdminContent()`  [INFERRED]
  ADMIN_HUB_MONITORING_PLAN.md → app/admin/admin-content.tsx
- `Admin Hub Monitoring Plan` --references--> `MarketplaceAdmin()`  [INFERRED]
  ADMIN_HUB_MONITORING_PLAN.md → components/admin/marketplace-admin.tsx
- `Marketplace + Badge System Implementation Plan` --references--> `evaluateBadges()`  [INFERRED]
  MARKETPLACE_IMPLEMENTATION_PLAN.md → lib/badges.ts
- `quote()` --semantically_similar_to--> `quoteFromRate()`  [INFERRED] [semantically similar]
  ml/pricing.py → lib/pricing.ts

## Import Cycles
- None detected.

## Communities (105 total, 42 thin omitted)

### Community 0 - "Admin Marketplace & Catalog Control"
Cohesion: 0.05
Nodes (58): AdminContentProps, AdminOrder, award (badge award function), emptyForm, FormState, MarketplaceAdmin(), ORDER_STATUSES, Props (+50 more)

### Community 1 - "Admin Payout Overrides & Crew Hub"
Cohesion: 0.05
Nodes (62): Crew, CrewHubAssignment(), PayoutOverride(), RISKS, Inference API Readme, ML API Requirements, Marketplace Perk - Payout Boost (pending_payout_boost_pct), Pricing Engine (+54 more)

### Community 2 - "Admin Hub & Layout UI Core"
Cohesion: 0.05
Nodes (28): AdminOrder, getDisplayWeight(), iconMap, ImpactCard(), ImpactCardProps, getDisplayWeight(), Badge(), badgeVariants (+20 more)

### Community 3 - "Daily Streak & Gamification System"
Cohesion: 0.05
Nodes (44): Daily Streak & Gamification System, S: Drive Disk Corruption Issue, Radix UI vs Base UI API Mixin Problem, Debugging Session Handoff Notes, Marketplace Implementation Plan, DailyRitual(), DailyRitualProps, MILESTONES (+36 more)

### Community 4 - "GPS Telemetry & Pickup Dispatch"
Cohesion: 0.05
Nodes (46): Real-time GPS Telemetry via Supabase Broadcast, Real-time GPS Telemetry Broadcast, Supabase Realtime Broadcast Telemetry Channel, Shared Estimator Contract (estimateQuote), CrewDashboardContent(), getCalculatedPayout, GPS Telemetry Broadcast Channel, GPS Telemetry Broadcast (useEffect) (+38 more)

### Community 5 - "ML Price Modeling & Pipeline"
Cohesion: 0.06
Nodes (41): ML Model Metrics (v2), ML Model Metrics v2 (duplicate), Price Estimates Seed SQL, ColumnTransformer, build(), DataFrame, Bridge the market-value model to the Trashium app price table.  Steps:   1. Pred, to_sql() (+33 more)

### Community 6 - "Project Configuration & Dependencies"
Cohesion: 0.05
Nodes (42): eslintConfig, dependencies, @base-ui/react, boneyard-js, class-variance-authority, clsx, leaflet, lucide-react (+34 more)

### Community 7 - "Corporate Info & Policy Pages"
Cohesion: 0.10
Nodes (20): impact, metadata, problems, steps, metadata, reasons, roles, metadata (+12 more)

### Community 8 - "Achievements & Badges UI"
Cohesion: 0.09
Nodes (28): Achievement, AchievementBadge, AchievementBadgeProps, badgeSizeMap, iconSizeMap, progressRingSizeMap, UserAchievement, Achievement (+20 more)

### Community 9 - "Admin Implementation Planning"
Cohesion: 0.07
Nodes (25): 0. Key finding — the admin hub is NOT empty (correct the mental model first), 10. ML model seam — keep the estimator drop-in ready (do NOT break this), 1. Decisions locked with the user, 2. Surface-by-surface plan, 3. Schema + backend (for the persisted override), 4. Icon, 5. Replace the mock analytics with real aggregates, 6. UI / UX (use `/frontend-design`, stay in the existing system) (+17 more)

### Community 10 - "Community 10"
Cohesion: 0.07
Nodes (26): 0. Decisions locked with the user (do not re-litigate), 10. Verification (MANDATORY — native, per the S: drive warning), 11. Guardrails (house rules — do not break), 1. The v2 ML serving contract (the spec we are matching), 2. Current state — what exists today, 2a. `price_estimates` table (live Supabase, project `fqbjjcbrxrokvdwkydze`), 2b. `lib/pricing.ts` (server) + `lib/pricing-math.ts` (client), 2c. Household estimator — `components/dashboard/schedule-pickup-modal.tsx` (+18 more)

### Community 11 - "Community 11"
Cohesion: 0.08
Nodes (25): dependencies, clsx, motion, next, react, react-dom, tailwind-merge, @tailwindcss/cli (+17 more)

### Community 12 - "Community 12"
Cohesion: 0.12
Nodes (19): normalizeSectorName(), Pickup Lifecycle, DashboardContentProps, DEFAULT_DAILY, handleSubmitQuiz, normalizePickup(), normalizeSectorName(), OPERATIONAL_SECTORS (+11 more)

### Community 13 - "Community 13"
Cohesion: 0.08
Nodes (24): Agent / AI Coding Rules, Authentication & Role System, `badges` / `user_badges`  *(gamification)*, Color Palette, Component Conventions, `daily_activity` / `streak_milestone_claims` *(daily streaks & rituals)*, Database Schema (Supabase Postgres), Environment Variables (+16 more)

### Community 14 - "Community 14"
Cohesion: 0.08
Nodes (7): AdminLoading(), Boneyard Config (Skeleton Loading), Boneyard Skeleton Loading Pattern, CrewLoading(), DashboardLoading(), MarketplaceLoading(), ProfileLoading()

### Community 15 - "Community 15"
Cohesion: 0.08
Nodes (23): aliases, components, hooks, lib, ui, utils, iconLibrary, menuAccent (+15 more)

### Community 16 - "Community 16"
Cohesion: 0.08
Nodes (23): 1. Features Implemented, 1. Kinetic Typography Loader — DONE & wired, 2. Current State & Verification, 2. Price Estimator Rehaul — built by VS Code extension, verified by us, 3. Admin Monitoring + Payout Override Hub — built by extension, verified by us, 3. Next Steps & Phase 2 Action Items, 4. Per-Stop Logistics Fix — DONE this session (fixes the crew ₹0), 5. PostgREST embed bug — FIXED this session (+15 more)

### Community 17 - "Community 17"
Cohesion: 0.12
Nodes (17): Gamification System, CountUp(), CountUpProps, LeaderboardCard, LeaderboardCardProps, LeaderboardRunOption, LeaderboardPodium, LeaderboardPodiumProps (+9 more)

### Community 18 - "Community 18"
Cohesion: 0.09
Nodes (22): 0. How to use this document (agent instructions), 1. Confirmed product decisions (do not re-litigate), 2. Current-state findings (already verified — trust these, don't re-derive), 3. Image handling (applies to badges AND marketplace items), 4. Out of scope (Phase 2 — do NOT build now), 5. [ASK USER] checkpoints, B-1. Schema (apply via MCP; mirror in `supabase_schema.sql`; NO RLS yet), B-2. Computation logic (+14 more)

### Community 19 - "Community 19"
Cohesion: 0.09
Nodes (22): 10. File map (`ml/`), 11. How to run, 12. Verification status (all passing), 13. Limitations & next steps, 14. Environment constraints & gotchas (for whoever continues), 15. Key constants (quick reference), 16. Session log (what we did, in order), 1. Project overview (+14 more)

### Community 20 - "Community 20"
Cohesion: 0.10
Nodes (20): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+12 more)

### Community 21 - "Community 21"
Cohesion: 0.14
Nodes (13): cormorant, dmSans, jetbrainsMono, metadata, RootLayout, syne, metadata, viewport (+5 more)

### Community 22 - "Community 22"
Cohesion: 0.17
Nodes (19): AreaType, BadgeCategory, BadgeUnlockType, ECO_LEVELS, EcoLevel, EcoLevelName, getEcoLevel(), getNextEcoLevel() (+11 more)

### Community 23 - "Community 23"
Cohesion: 0.10
Nodes (19): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+11 more)

### Community 24 - "Community 24"
Cohesion: 0.11
Nodes (18): 1.1 What the model actually consumes, 1.2 How user payout is derived (`ml/pricing.py`, locked formula), 1.3 The three tables — what each needs, 1. Input / Output Analysis, 2. Avoid Waste-Type Squashing — the 20 materials, 3.1 `config.py` — add a material→bucket map (keep the category map for fallback), 3.2 `data_prep.py` — add the leaf→bucket column (no feature change), 3.3 `build_price_table.py` — group by material, not by bucket (+10 more)

### Community 25 - "Community 25"
Cohesion: 0.18
Nodes (17): 20-Tier Eco-Level System (TRASHIUM_EVALUATION_TIERS), Daily Ritual Gamification System, Green Credits - Gamification Currency, Marketplace Access Gate (500 credits + 1 pickup), DashboardContent(), getSectorRankings, handleCancelPickup, handleLogWasteSegregation (+9 more)

### Community 26 - "Community 26"
Cohesion: 0.22
Nodes (14): Phase 2 Badge Locks (streak/referral/quiz), badgeCurrent(), BadgeSignals, evaluateBadges(), isBadgeUnlocked(), KG_BADGE_MATERIAL, MEASURABLE, ProfileLike (+6 more)

### Community 27 - "Community 27"
Cohesion: 0.14
Nodes (10): PointsLevelList, pointsLevelListIconMap, PointsLevelListIconType, PointsLevelsList, PointsLevelsListProps, PointsSubLevelList, PointsLevelsTimeline, PointsLevelsTimelineProps (+2 more)

### Community 28 - "Community 28"
Cohesion: 0.19
Nodes (13): CLAUDE.md — AI Agent Guide, Dataset Demand/Risk Signal Correction, Eco Gamification System (Credits, Levels), ML Pricing Pipeline, Moving Average Trend Guardrail, Operational Sectors (West Bengal Regions), Row Level Security (RLS) Pattern, Server vs Client Component Split Pattern (+5 more)

### Community 29 - "Community 29"
Cohesion: 0.18
Nodes (8): Crew Operations, RouteStop, defaultIcon, RouteMapProps, SECTOR_COORDINATES, vehicleIcon, depotIcon, Props

### Community 30 - "Community 30"
Cohesion: 0.22
Nodes (10): 20-Tier Eco-Level Gamification System, getLevelNumber(), getNextTier(), getTier(), Tier, TIER_ICON_FILENAMES, TRASHIUM_EVALUATION_TIERS, ECO_LEVELS (deprecated 5-tier) (+2 more)

### Community 31 - "Community 31"
Cohesion: 0.27
Nodes (8): AdminPage(), metadata, CrewDashboardPage(), resolveHubSectors(), price_estimates Table, createClient(), metadata, TrackingPage()

### Community 32 - "Community 32"
Cohesion: 0.33
Nodes (10): _auth(), BatchIn, predict(), predict_batch(), PredictIn, PredictOut, Trashium pricing model — live inference service (FastAPI).  WHY THIS EXISTS   sc, Enforce the shared bearer token when API_TOKEN is configured (no-op otherwise). (+2 more)

### Community 33 - "Community 33"
Cohesion: 0.17
Nodes (11): Connect Next.js (Vercel env vars), Deploy, Docker (any host), Endpoints, Fly.io, Railway (simplest), Render, Run locally (+3 more)

### Community 34 - "Community 34"
Cohesion: 0.24
Nodes (10): Commission Lever for Trashium Profit (c=0.15), config.py — Business Knobs & Schema, Leakage-Free Feature Design, Logistics Cost Rate Card (Distance-Based Formula), Predict Market Value (Not Payout) Strategy, Minimum Quantity Rule (Pending Feature), User Payout Per Kg Formula, pricing.py — Single Source of Truth for Pricing Math (+2 more)

### Community 35 - "Community 35"
Cohesion: 0.27
Nodes (10): Dataset Regeneration for Learnable Risk & Demand, dataset_learnable.xlsx — Canonical Training File, Linear Regression on log(Market Value) — Production Model, Log-transformed Market Value as Model Target, MAPE as Primary Pricing Evaluation Metric, Random Forest on log(Market Value) — Challenger Model, regenerate_dataset.py — Dataset Corrector, scikit-learn ML Library (+2 more)

### Community 36 - "Community 36"
Cohesion: 0.29
Nodes (8): Client-Side Route Optimization (NN + 2-opt), fetchOsrmRoute(), LatLng, haversineKm(), OptimizedRoute, optimizeRoute(), routeDistance(), TruckConstraints

### Community 37 - "Community 37"
Cohesion: 0.22
Nodes (7): ImpactCounter(), ImpactCounterProps, StatItem, AnimatedCounter(), AnimatedCounterProps, StatCard(), StatCardProps

### Community 38 - "Community 38"
Cohesion: 0.28
Nodes (4): features, HeroSection(), HowItWorks(), steps

### Community 39 - "Community 39"
Cohesion: 0.25
Nodes (8): AdminContent(), fetchFullFledgedData, getSectorRankings, handleExportSectorSummary, handleStatusUpdate, isTimeDiscrepancy, Sector-Based Operations Model, Sector-based Leaderboard System

### Community 40 - "Community 40"
Cohesion: 0.25
Nodes (7): Business formulas (single source of truth: `pricing.py`), Data corrections (`regenerate_dataset.py`), How it maps to the app, Real recycler price feed (optional override), Run the pipeline, Trashium Pricing ML (v2 — market-value model), What the models predict

### Community 41 - "Community 41"
Cohesion: 0.29
Nodes (6): Dual Balance Credit Tradeoff (D1), Badges — bucket: `gamification-badges`, Daily Grove Ritual & Streaks — Vector Assets, Image Manifest — Badges & Marketplace, Marketplace items — bucket: `marketplace-items`, Marketplace + Badge System Implementation Plan

### Community 42 - "Community 42"
Cohesion: 0.48
Nodes (6): getRate(), PickupQuote, quoteFromRate(), quotePickup(), RateRow, Trashium AI Agent Guide (CLAUDE.md)

### Community 44 - "Community 44"
Cohesion: 0.29
Nodes (3): PointsChartDataPoint, PointsChartLevel, PointsChartProps

### Community 45 - "Community 45"
Cohesion: 0.40
Nodes (4): TileRatesBySector, FlippingRatesProps, RecyclableTier, recyclableTiers

### Community 46 - "Community 46"
Cohesion: 0.40
Nodes (3): geistMono, geistSans, metadata

### Community 47 - "Community 47"
Cohesion: 0.50
Nodes (5): build_price_table.py — Rate Table Generator, Real Recycler Market Price Feed (Optional Override), price_estimates Supabase Table, publish_to_supabase.py — Rate Table Upserter, Supabase Backend Integration

### Community 50 - "Community 50"
Cohesion: 0.60
Nodes (3): config, proxy(), updateSession()

### Community 51 - "Community 51"
Cohesion: 0.50
Nodes (3): Next.js Agent Rules, CLAUDE.md Documentation, nextConfig

### Community 52 - "Community 52"
Cohesion: 0.67
Nodes (3): HomePage(), getTileRatesBySector(), global_impact Table

### Community 53 - "Community 53"
Cohesion: 0.50
Nodes (4): Formula Leakage Demo (Payout Prediction), Log-Target Rationale for Pricing Models, Market Value as ML Prediction Target, Pricing Business Formula (Single Source of Truth)

### Community 54 - "Community 54"
Cohesion: 0.50
Nodes (4): Next.js Agent Rules (Breaking Changes Warning), Trashium Next.js Web Application, Next.js Logo SVG, Vercel Logo SVG (Triangle)

### Community 56 - "Community 56"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

### Community 57 - "Community 57"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

## Knowledge Gaps
- **502 isolated node(s):** `AdminOrder`, `metadata`, `OptimizedRouteMap`, `CREW_SECTORS`, `CrewDashboardProps` (+497 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **42 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `price_estimates Supabase Table` connect `Community 47` to `Community 34`, `Community 42`, `Community 28`, `ML Price Modeling & Pipeline`?**
  _High betweenness centrality (0.046) - this node is a cross-community bridge._
- **Why does `createClient()` connect `Admin Marketplace & Catalog Control` to `Admin Payout Overrides & Crew Hub`, `Admin Hub & Layout UI Core`, `GPS Telemetry & Pickup Dispatch`, `Community 39`, `Community 12`, `Community 25`, `Community 26`, `Community 31`?**
  _High betweenness centrality (0.045) - this node is a cross-community bridge._
- **Why does `getRate()` connect `Community 42` to `Admin Payout Overrides & Crew Hub`, `Community 31`, `Community 47`?**
  _High betweenness centrality (0.043) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `createClient()` (e.g. with `createClient()` and `updateSession()`) actually correct?**
  _`createClient()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **Are the 2 inferred relationships involving `CrewDashboardContent()` (e.g. with `AdminContent()` and `Real-time GPS Telemetry via Supabase Broadcast`) actually correct?**
  _`CrewDashboardContent()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `AdminOrder`, `metadata`, `OptimizedRouteMap` to the rest of the system?**
  _536 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Admin Marketplace & Catalog Control` be split into smaller, more focused modules?**
  _Cohesion score 0.05290490100616683 - nodes in this community are weakly interconnected._