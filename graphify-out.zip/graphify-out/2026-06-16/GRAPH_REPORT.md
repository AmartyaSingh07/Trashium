# Graph Report - Trashium  (2026-06-16)

## Corpus Check
- 112 files · ~46,455 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 730 nodes · 1040 edges · 54 communities (37 shown, 17 thin omitted)
- Extraction: 97% EXTRACTED · 3% INFERRED · 0% AMBIGUOUS · INFERRED: 36 edges (avg confidence: 0.88)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `02c6331e`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Admin Dashboard Logic|Admin Dashboard Logic]]
- [[_COMMUNITY_App Pages & Routing|App Pages & Routing]]
- [[_COMMUNITY_Pickup Scheduling & Sectors|Pickup Scheduling & Sectors]]
- [[_COMMUNITY_User Dashboard & Gamification|User Dashboard & Gamification]]
- [[_COMMUNITY_Crew GPS Telemetry|Crew GPS Telemetry]]
- [[_COMMUNITY_Project Config & Dependencies|Project Config & Dependencies]]
- [[_COMMUNITY_ML Pricing Pipeline|ML Pricing Pipeline]]
- [[_COMMUNITY_Achievement Badge UI|Achievement Badge UI]]
- [[_COMMUNITY_Streak & Calendar UI|Streak & Calendar UI]]
- [[_COMMUNITY_Trashium-App Scaffold|Trashium-App Scaffold]]
- [[_COMMUNITY_Shadcn UI Alias Config|Shadcn UI Alias Config]]
- [[_COMMUNITY_TypeScript Compiler Config|TypeScript Compiler Config]]
- [[_COMMUNITY_Trashium-App TSConfig|Trashium-App TSConfig]]
- [[_COMMUNITY_Leaderboard UI|Leaderboard UI]]
- [[_COMMUNITY_ML Architecture Concepts|ML Architecture Concepts]]
- [[_COMMUNITY_Points & Awards UI|Points & Awards UI]]
- [[_COMMUNITY_Points Levels UI|Points Levels UI]]
- [[_COMMUNITY_Root Layout & Fonts|Root Layout & Fonts]]
- [[_COMMUNITY_ML Formula & Anti-Leakage|ML Formula & Anti-Leakage]]
- [[_COMMUNITY_Trashium-App Shell|Trashium-App Shell]]
- [[_COMMUNITY_Community 20|Community 20]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 37|Community 37]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]
- [[_COMMUNITY_Community 42|Community 42]]
- [[_COMMUNITY_Community 43|Community 43]]
- [[_COMMUNITY_Community 44|Community 44]]
- [[_COMMUNITY_Community 45|Community 45]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 48|Community 48]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 53|Community 53]]

## God Nodes (most connected - your core abstractions)
1. `createClient()` - 19 edges
2. `Trashium Pricing ML — Project Context & Session Handoff` - 18 edges
3. `Button()` - 17 edges
4. `createClient()` - 17 edges
5. `compilerOptions` - 16 edges
6. `compilerOptions` - 16 edges
7. `Navbar()` - 13 edges
8. `price_estimates Supabase Table` - 12 edges
9. `PickupRequest` - 11 edges
10. `Trashium — AI Agent Guide` - 11 edges

## Surprising Connections (you probably didn't know these)
- `quote()` --semantically_similar_to--> `quoteFromRate()`  [INFERRED] [semantically similar]
  ml/pricing.py → lib/pricing.ts
- `publish_to_supabase.py — Rate Table Upserter` --shares_data_with--> `price_estimates Supabase Table`  [EXTRACTED]
  ml/Trashium_Pricing_ML_Context.md → lib/pricing.ts
- `getDisplayWeight()` --semantically_similar_to--> `getDisplayWeight()`  [INFERRED] [semantically similar]
  app/admin/admin-content.tsx → components/dashboard/recent-pickups.tsx
- `ZONE_HOME_COORDINATES` --semantically_similar_to--> `OPERATIONAL_SECTORS`  [INFERRED] [semantically similar]
  app/dashboard/tracking/tracking-content.tsx → ml/config.py
- `lib/pricing.ts — Frontend Pricing Mirror` --shares_data_with--> `price_estimates Supabase Table`  [EXTRACTED]
  ml/Trashium_Pricing_ML_Context.md → lib/pricing.ts

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **ML Pricing Pipeline: train → build → publish → serve** — ml_build_price_table_build, ml_publish_to_supabase_main, concept_price_estimates_table, lib_pricing_quotepickup [INFERRED 0.85]
- **Real-Time Crew GPS Telemetry Flow (broadcast → subscribe → render)** — crew_crew_content_crewdashboardcontent, concept_realtime_telemetry_channel, tracking_tracking_content_trackingcontent, tracking_tracking_map_trackingmap [INFERRED 0.95]
- **Navbar Composition: Layout Navbar wraps ResizableNavbar primitives** — layout_navbar_navbar, ui_resizable_navbar_navbar, ui_resizable_navbar_navbody, ui_resizable_navbar_mobilenav [EXTRACTED 0.95]
- **ML Pricing Pipeline: Dataset → Train → Verify → Publish** — ml_regenerate_dataset, ml_train_models, ml_verify, concept_price_estimates_table [EXTRACTED 1.00]
- **DB Pricing Layer: Schema Migration + ML Seed Data** — migrations_0002_pricing_ml, migrations_0003_seed_price_estimates, concept_price_estimates_table [EXTRACTED 1.00]
- **Next.js App Shell: Layout + Page + Config** — app_layout, app_page, app_next_config, app_package_json [INFERRED 0.85]
- **ML Pipeline Core Flow: Regenerate → Train → Build Rate Table → Publish** — concept_regenerate_dataset, concept_train_models, concept_build_price_table, concept_publish_to_supabase [EXTRACTED 1.00]
- **Pricing Formula Triad: Market Value + Commission + Logistics → Payout** — concept_payout_formula, concept_commission_lever, concept_logistics_rate_card [EXTRACTED 1.00]
- **Model Selection: LR vs RF vs Moving Average Guardrail** — concept_linear_regression_mv, concept_random_forest_mv, concept_moving_average_guardrail [EXTRACTED 1.00]

## Communities (54 total, 17 thin omitted)

### Community 0 - "Admin Dashboard Logic"
Cohesion: 0.06
Nodes (28): AdminContentProps, areas, getDisplayWeight(), wasteTypes, getDisplayWeight(), RecentPickupsProps, TRASHIUM_PICKUP_SLOTS, AreaType (+20 more)

### Community 1 - "App Pages & Routing"
Cohesion: 0.13
Nodes (16): getSectorRankings, normalizeSectorName(), OPERATIONAL_SECTORS, DashboardContent(), getSectorRankings, getStreakPeriods(), handleLogWasteSegregation, handleSubmitQuiz (+8 more)

### Community 2 - "Pickup Scheduling & Sectors"
Cohesion: 0.05
Nodes (42): AdminContent(), OPERATIONAL_SECTORS, SchedulePickupModal(), SchedulePickupModalProps, TRASHIUM_PICKUP_SLOTS, wasteTypes, LoginPage(), SignupPage() (+34 more)

### Community 3 - "User Dashboard & Gamification"
Cohesion: 0.05
Nodes (47): AdminPage(), metadata, HomePage(), CrewDashboardPage(), DashboardContentProps, DashboardPage(), metadata, features (+39 more)

### Community 4 - "Crew GPS Telemetry"
Cohesion: 0.07
Nodes (38): Supabase Realtime Broadcast Telemetry Channel, CrewDashboardContent(), CrewDashboardProps, CrewRouteMap, getCalculatedPayout, GPS Telemetry Broadcast Channel, handleReportIssue, PickupRequest (+30 more)

### Community 5 - "Project Config & Dependencies"
Cohesion: 0.05
Nodes (41): eslintConfig, dependencies, @base-ui/react, class-variance-authority, clsx, leaflet, lucide-react, motion (+33 more)

### Community 6 - "ML Pricing Pipeline"
Cohesion: 0.08
Nodes (33): ML Model Metrics (v2), ML Model Metrics v2 (duplicate), Price Estimates Seed SQL, build(), DataFrame, Bridge the market-value model to the Trashium app price table.  Steps:   1. Pred, to_sql(), Market Value as ML Target (v2 Rationale) (+25 more)

### Community 7 - "Achievement Badge UI"
Cohesion: 0.18
Nodes (15): Achievement, AchievementBadge, AchievementBadgeProps, badgeSizeMap, iconSizeMap, progressRingSizeMap, UserAchievement, Achievement (+7 more)

### Community 8 - "Streak & Calendar UI"
Cohesion: 0.15
Nodes (15): didUseFreezeOnDate(), formatDateKey(), getDateKey(), getGitCells(), getGitDates(), getWeekDates(), getWeekdayIndex(), getWeekStart() (+7 more)

### Community 9 - "Trashium-App Scaffold"
Cohesion: 0.08
Nodes (25): dependencies, clsx, motion, next, react, react-dom, tailwind-merge, @tailwindcss/cli (+17 more)

### Community 10 - "Shadcn UI Alias Config"
Cohesion: 0.09
Nodes (22): aliases, components, hooks, lib, ui, utils, iconLibrary, menuAccent (+14 more)

### Community 11 - "TypeScript Compiler Config"
Cohesion: 0.10
Nodes (20): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+12 more)

### Community 12 - "Trashium-App TSConfig"
Cohesion: 0.10
Nodes (19): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+11 more)

### Community 13 - "Leaderboard UI"
Cohesion: 0.15
Nodes (14): LeaderboardCard, LeaderboardCardProps, LeaderboardRunOption, LeaderboardPodium, LeaderboardPodiumProps, LeaderboardRanking, PODIUM_CONFIG, podiumVariants (+6 more)

### Community 14 - "ML Architecture Concepts"
Cohesion: 0.07
Nodes (36): CLAUDE.md — AI Agent Guide, ColumnTransformer, build_price_table.py — Rate Table Generator, Chronological Train/Test Split, Dataset Demand/Risk Signal Correction, Eco Gamification System (Credits, Levels), Formula Leakage Demo (Payout Prediction), Log-Target Rationale for Pricing Models (+28 more)

### Community 15 - "Points & Awards UI"
Cohesion: 0.13
Nodes (9): PointsAward, PointsAwards, PointsAwardsProps, PointsAwardTrigger, TooltipContent, triggerIconMap, PointsBadge, PointsBadgeProps (+1 more)

### Community 16 - "Points Levels UI"
Cohesion: 0.14
Nodes (10): PointsLevelList, pointsLevelListIconMap, PointsLevelListIconType, PointsLevelsList, PointsLevelsListProps, PointsSubLevelList, PointsLevelsTimeline, PointsLevelsTimelineProps (+2 more)

### Community 17 - "Root Layout & Fonts"
Cohesion: 0.20
Nodes (8): cormorant, dmSans, jetbrainsMono, syne, metadata, Ribbons(), RibbonsProps, Toaster()

### Community 18 - "ML Formula & Anti-Leakage"
Cohesion: 0.13
Nodes (23): Commission Lever for Trashium Profit (c=0.15), config.py — Business Knobs & Schema, Dataset Regeneration for Learnable Risk & Demand, dataset_learnable.xlsx — Canonical Training File, Fallback Rates for Glass/Organic/Mixed Waste, Leakage-Free Feature Design, Linear Regression on log(Market Value) — Production Model, Log-transformed Market Value as Model Target (+15 more)

### Community 19 - "Trashium-App Shell"
Cohesion: 0.40
Nodes (3): geistMono, geistSans, metadata

### Community 20 - "Community 20"
Cohesion: 0.18
Nodes (8): Next.js Agent Rules (Breaking Changes Warning), Trashium Next.js Web Application, Next.js Logo SVG, Vercel Logo SVG (Triangle), This is NOT the Next.js you know, Deploy on Vercel, Getting Started, Learn More

### Community 21 - "Community 21"
Cohesion: 0.09
Nodes (22): 10. File map (`ml/`), 11. How to run, 12. Verification status (all passing), 13. Limitations & next steps, 14. Environment constraints & gotchas (for whoever continues), 15. Key constants (quick reference), 16. Session log (what we did, in order), 1. Project overview (+14 more)

### Community 23 - "Community 23"
Cohesion: 0.20
Nodes (6): iconMap, ImpactCardProps, Card(), CardContent(), CardHeader(), CardTitle()

### Community 24 - "Community 24"
Cohesion: 0.29
Nodes (4): defaultIcon, RouteMapProps, SECTOR_COORDINATES, vehicleIcon

### Community 25 - "Community 25"
Cohesion: 0.25
Nodes (8): Achievement, AchievementList, AchievementListProps, achievementListVariants, badgeSizeMap, iconSizeMap, progressSizeMap, UserAchievement

### Community 27 - "Community 27"
Cohesion: 0.29
Nodes (3): PointsChartDataPoint, PointsChartLevel, PointsChartProps

### Community 28 - "Community 28"
Cohesion: 0.50
Nodes (3): Next.js Agent Rules, CLAUDE.md Documentation, nextConfig

### Community 29 - "Community 29"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

### Community 30 - "Community 30"
Cohesion: 0.40
Nodes (5): Achievement, AchievementGrid, AchievementGridProps, achievementGridVariants, UserAchievement

### Community 42 - "Community 42"
Cohesion: 0.09
Nodes (21): Agent / AI Coding Rules, Authentication & Role System, Color Palette, Component Conventions, Database Schema (Supabase Postgres), Environment Variables, Fonts (CSS variables), `global_impact` (+13 more)

## Knowledge Gaps
- **307 isolated node(s):** `wasteTypes`, `areas`, `metadata`, `CrewRouteMap`, `CrewDashboardProps` (+302 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **17 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `price_estimates Supabase Table` connect `ML Architecture Concepts` to `ML Formula & Anti-Leakage`, `User Dashboard & Gamification`, `ML Pricing Pipeline`?**
  _High betweenness centrality (0.159) - this node is a cross-community bridge._
- **Why does `getRate()` connect `User Dashboard & Gamification` to `ML Architecture Concepts`?**
  _High betweenness centrality (0.144) - this node is a cross-community bridge._
- **Why does `createClient()` connect `User Dashboard & Gamification` to `Pickup Scheduling & Sectors`?**
  _High betweenness centrality (0.123) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `createClient()` (e.g. with `createClient()` and `updateSession()`) actually correct?**
  _`createClient()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `wasteTypes`, `areas`, `metadata` to the rest of the system?**
  _327 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Admin Dashboard Logic` be split into smaller, more focused modules?**
  _Cohesion score 0.06207482993197279 - nodes in this community are weakly interconnected._
- **Should `App Pages & Routing` be split into smaller, more focused modules?**
  _Cohesion score 0.13157894736842105 - nodes in this community are weakly interconnected._