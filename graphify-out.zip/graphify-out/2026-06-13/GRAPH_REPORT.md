# Graph Report - .  (2026-06-13)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 453 nodes · 784 edges · 25 communities (18 shown, 7 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 15 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `02c6331e`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Profile UI and Badges|Profile UI and Badges]]
- [[_COMMUNITY_Landing and App Routing Pages|Landing and App Routing Pages]]
- [[_COMMUNITY_Streak Tracker UI|Streak Tracker UI]]
- [[_COMMUNITY_Data Types and Models|Data Types and Models]]
- [[_COMMUNITY_Node Package Dependencies|Node Package Dependencies]]
- [[_COMMUNITY_Shadcn Path Configuration|Shadcn Path Configuration]]
- [[_COMMUNITY_Achievement Badge UI|Achievement Badge UI]]
- [[_COMMUNITY_Dashboard and Admin Views|Dashboard and Admin Views]]
- [[_COMMUNITY_TypeScript Compiler Configuration|TypeScript Compiler Configuration]]
- [[_COMMUNITY_Gamification Leaderboards UI|Gamification Leaderboards UI]]
- [[_COMMUNITY_Auth and Layout Navigation|Auth and Layout Navigation]]
- [[_COMMUNITY_Dashboard and Admin Views|Dashboard and Admin Views]]
- [[_COMMUNITY_Gamification Points Awards UI|Gamification Points Awards UI]]
- [[_COMMUNITY_Earthy Stats Cards|Earthy Stats Cards]]
- [[_COMMUNITY_Achievement Badge UI|Achievement Badge UI]]
- [[_COMMUNITY_Gamification Leaderboards UI|Gamification Leaderboards UI]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Landing and App Routing Pages|Landing and App Routing Pages]]
- [[_COMMUNITY_PostCSS Style Configuration|PostCSS Style Configuration]]
- [[_COMMUNITY_Community 16|Community 16]]
- [[_COMMUNITY_Community 17|Community 17]]
- [[_COMMUNITY_Community 21|Community 21]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]

## God Nodes (most connected - your core abstractions)
1. `cn()` - 85 edges
2. `Button()` - 18 edges
3. `compilerOptions` - 16 edges
4. `createClient()` - 12 edges
5. `createClient()` - 11 edges
6. `PickupRequest` - 11 edges
7. `Profile` - 8 edges
8. `tailwind` - 6 edges
9. `aliases` - 6 edges
10. `AchievementBadge` - 6 edges

## Surprising Connections (you probably didn't know these)
- `getDisplayWeight()` --semantically_similar_to--> `getDisplayWeight()`  [INFERRED] [semantically similar]
  app/admin/admin-content.tsx → components/dashboard/recent-pickups.tsx
- `CardDescription()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts
- `CardAction()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts
- `CardFooter()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts
- `PointsChart()` --calls--> `cn()`  [EXTRACTED]
  components/ui/points-chart.tsx → lib/utils.ts

## Import Cycles
- None detected.

## Communities (25 total, 7 thin omitted)

### Community 0 - "Profile UI and Badges"
Cohesion: 0.07
Nodes (41): areas, wasteTypes, cn(), Avatar(), AvatarBadge(), AvatarFallback(), AvatarGroup(), AvatarGroupCount() (+33 more)

### Community 1 - "Landing and App Routing Pages"
Cohesion: 0.09
Nodes (25): CrewDashboardProps, CrewRouteMap, PickupRequest, OPERATIONAL_SECTORS, SchedulePickupModalProps, TRASHIUM_PICKUP_SLOTS, wasteTypes, Navbar() (+17 more)

### Community 2 - "Streak Tracker UI"
Cohesion: 0.08
Nodes (29): AdminContentProps, getDisplayWeight(), DashboardContentProps, getDisplayWeight(), RecentPickupsProps, TRASHIUM_PICKUP_SLOTS, ImpactCounterProps, StatItem (+21 more)

### Community 3 - "Data Types and Models"
Cohesion: 0.05
Nodes (39): eslintConfig, dependencies, @base-ui/react, class-variance-authority, clsx, leaflet, lucide-react, next (+31 more)

### Community 4 - "Node Package Dependencies"
Cohesion: 0.09
Nodes (28): Achievement, AchievementBadge, AchievementBadgeProps, badgeSizeMap, iconSizeMap, progressRingSizeMap, UserAchievement, Achievement (+20 more)

### Community 5 - "Shadcn Path Configuration"
Cohesion: 0.09
Nodes (25): getSectorRankings, normalizeSectorName(), OPERATIONAL_SECTORS, DashboardContent(), getSectorRankings, getStreakPeriods(), handleLogWasteSegregation, handleSubmitQuiz (+17 more)

### Community 6 - "Achievement Badge UI"
Cohesion: 0.09
Nodes (17): AdminPage(), metadata, HomePage(), DashboardPage(), metadata, features, steps, footerLinks (+9 more)

### Community 7 - "Dashboard and Admin Views"
Cohesion: 0.07
Nodes (20): PointsBoost, PointsBoostCta, PointsBoostData, PointsBoostProps, PointsBoostStatus, PointsChart(), PointsChartDataPoint, PointsChartLevel (+12 more)

### Community 8 - "TypeScript Compiler Configuration"
Cohesion: 0.10
Nodes (22): StreakBadge, StreakBadgeProps, streakBadgeVariants, StreakResponse, didUseFreezeOnDate(), formatDateKey(), getDateKey(), getGitCells() (+14 more)

### Community 9 - "Gamification Leaderboards UI"
Cohesion: 0.09
Nodes (21): aliases, components, hooks, lib, ui, utils, iconLibrary, menuAccent (+13 more)

### Community 10 - "Auth and Layout Navigation"
Cohesion: 0.10
Nodes (20): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+12 more)

### Community 11 - "Dashboard and Admin Views"
Cohesion: 0.15
Nodes (14): LeaderboardCard, LeaderboardCardProps, LeaderboardRunOption, LeaderboardPodium, LeaderboardPodiumProps, LeaderboardRanking, PODIUM_CONFIG, podiumVariants (+6 more)

### Community 12 - "Gamification Points Awards UI"
Cohesion: 0.13
Nodes (9): PointsAward, PointsAwards, PointsAwardsProps, PointsAwardTrigger, TooltipContent, triggerIconMap, PointsBadge, PointsBadgeProps (+1 more)

### Community 13 - "Earthy Stats Cards"
Cohesion: 0.20
Nodes (9): cormorant, dmSans, jetbrainsMono, metadata, RootLayout(), syne, Ribbons(), RibbonsProps (+1 more)

### Community 14 - "Achievement Badge UI"
Cohesion: 0.29
Nodes (4): defaultIcon, RouteMapProps, SECTOR_COORDINATES, vehicleIcon

### Community 15 - "Gamification Leaderboards UI"
Cohesion: 0.50
Nodes (3): Next.js Agent Rules, CLAUDE.md Documentation, nextConfig

### Community 16 - "Community 16"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

## Knowledge Gaps
- **182 isolated node(s):** `enabled`, `wasteTypes`, `areas`, `metadata`, `CrewRouteMap` (+177 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **7 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `cn()` connect `Profile UI and Badges` to `Landing and App Routing Pages`, `Node Package Dependencies`, `Shadcn Path Configuration`, `Achievement Badge UI`, `Dashboard and Admin Views`, `TypeScript Compiler Configuration`, `Dashboard and Admin Views`, `Gamification Points Awards UI`?**
  _High betweenness centrality (0.212) - this node is a cross-community bridge._
- **Why does `createClient()` connect `Landing and App Routing Pages` to `Profile UI and Badges`, `Streak Tracker UI`, `Shadcn Path Configuration`, `Achievement Badge UI`?**
  _High betweenness centrality (0.039) - this node is a cross-community bridge._
- **Why does `createClient()` connect `Achievement Badge UI` to `Landing and App Routing Pages`, `Streak Tracker UI`?**
  _High betweenness centrality (0.028) - this node is a cross-community bridge._
- **What connects `enabled`, `wasteTypes`, `areas` to the rest of the system?**
  _182 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Profile UI and Badges` be split into smaller, more focused modules?**
  _Cohesion score 0.07477288609364081 - nodes in this community are weakly interconnected._
- **Should `Landing and App Routing Pages` be split into smaller, more focused modules?**
  _Cohesion score 0.09413067552602436 - nodes in this community are weakly interconnected._
- **Should `Streak Tracker UI` be split into smaller, more focused modules?**
  _Cohesion score 0.08170731707317073 - nodes in this community are weakly interconnected._