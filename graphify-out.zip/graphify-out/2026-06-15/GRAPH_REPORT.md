# Graph Report - Trashium  (2026-06-15)

## Corpus Check
- 105 files · ~39,784 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 569 nodes · 919 edges · 43 communities (33 shown, 10 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 15 edges (avg confidence: 0.85)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `02c6331e`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Admin Hub Dashboard|Admin Hub Dashboard]]
- [[_COMMUNITY_Crew Hub Operations|Crew Hub Operations]]
- [[_COMMUNITY_Metrics & Impact Counters|Metrics & Impact Counters]]
- [[_COMMUNITY_Package Dependencies|Package Dependencies]]
- [[_COMMUNITY_Achievements UI System|Achievements UI System]]
- [[_COMMUNITY_Household Waste Operations|Household Waste Operations]]
- [[_COMMUNITY_App Routing & Pages|App Routing & Pages]]
- [[_COMMUNITY_Points Boost System|Points Boost System]]
- [[_COMMUNITY_Streak Tracking Calendar|Streak Tracking Calendar]]
- [[_COMMUNITY_Shared Component Constants|Shared Component Constants]]
- [[_COMMUNITY_TypeScript Compiler Config|TypeScript Compiler Config]]
- [[_COMMUNITY_Leaderboard Podium UI|Leaderboard Podium UI]]
- [[_COMMUNITY_Points Awards System|Points Awards System]]
- [[_COMMUNITY_Typography & Layout Ribbons|Typography & Layout Ribbons]]
- [[_COMMUNITY_Crew Navigation Maps|Crew Navigation Maps]]
- [[_COMMUNITY_Agent Rules & Configuration|Agent Rules & Configuration]]
- [[_COMMUNITY_Project README Documentation|Project README Documentation]]
- [[_COMMUNITY_Planning Metadata Config|Planning Metadata Config]]
- [[_COMMUNITY_Next.js Agent Guidelines|Next.js Agent Guidelines]]
- [[_COMMUNITY_PostCSS Configuration|PostCSS Configuration]]
- [[_COMMUNITY_Graphify Rule System|Graphify Rule System]]
- [[_COMMUNITY_Graphify Documentation|Graphify Documentation]]
- [[_COMMUNITY_Documentation Files|Documentation Files]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]
- [[_COMMUNITY_Community 33|Community 33]]
- [[_COMMUNITY_Community 34|Community 34]]
- [[_COMMUNITY_Community 35|Community 35]]
- [[_COMMUNITY_Community 36|Community 36]]
- [[_COMMUNITY_Community 38|Community 38]]
- [[_COMMUNITY_Community 39|Community 39]]
- [[_COMMUNITY_Community 40|Community 40]]
- [[_COMMUNITY_Community 41|Community 41]]

## God Nodes (most connected - your core abstractions)
1. `cn()` - 85 edges
2. `Button()` - 18 edges
3. `createClient()` - 18 edges
4. `createClient()` - 17 edges
5. `compilerOptions` - 16 edges
6. `compilerOptions` - 16 edges
7. `PickupRequest` - 11 edges
8. `Profile` - 8 edges
9. `tailwind` - 6 edges
10. `aliases` - 6 edges

## Surprising Connections (you probably didn't know these)
- `getDisplayWeight()` --semantically_similar_to--> `getDisplayWeight()`  [INFERRED] [semantically similar]
  app/admin/admin-content.tsx → components/dashboard/recent-pickups.tsx
- `RecentPickupsProps` --references--> `PickupRequest`  [EXTRACTED]
  components/dashboard/recent-pickups.tsx → lib/types.ts
- `CardDescription()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts
- `CardAction()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts
- `CardFooter()` --calls--> `cn()`  [EXTRACTED]
  components/ui/card.tsx → lib/utils.ts

## Import Cycles
- None detected.

## Communities (43 total, 10 thin omitted)

### Community 0 - "Admin Hub Dashboard"
Cohesion: 0.07
Nodes (44): AdminContentProps, areas, wasteTypes, AreaType, PriceEstimate, WasteType, cn(), Avatar() (+36 more)

### Community 1 - "Crew Hub Operations"
Cohesion: 0.07
Nodes (37): AdminContent(), CrewDashboardContent(), CrewDashboardProps, CrewRouteMap, PickupRequest, OPERATIONAL_SECTORS, SchedulePickupModal(), SchedulePickupModalProps (+29 more)

### Community 2 - "Metrics & Impact Counters"
Cohesion: 0.08
Nodes (35): AdminPage(), metadata, CrewDashboardPage(), DashboardContentProps, DashboardPage(), metadata, footerLinks, OPERATIONAL_SECTORS (+27 more)

### Community 3 - "Package Dependencies"
Cohesion: 0.05
Nodes (40): eslintConfig, dependencies, @base-ui/react, class-variance-authority, clsx, leaflet, lucide-react, motion (+32 more)

### Community 4 - "Achievements UI System"
Cohesion: 0.09
Nodes (28): Achievement, AchievementBadge, AchievementBadgeProps, badgeSizeMap, iconSizeMap, progressRingSizeMap, UserAchievement, Achievement (+20 more)

### Community 5 - "Household Waste Operations"
Cohesion: 0.22
Nodes (10): ColumnTransformer, add_features(), build_preprocessor(), chrono_split(), load_raw(), DataFrame, Data loading, feature engineering, and the shared scikit-learn preprocessor.  Us, Read the dataset (xlsx or csv) and parse the date column. (+2 more)

### Community 6 - "App Routing & Pages"
Cohesion: 0.11
Nodes (13): HomePage(), features, HeroSection(), HowItWorks(), steps, ImpactCounter(), ImpactCounterProps, StatItem (+5 more)

### Community 7 - "Points Boost System"
Cohesion: 0.60
Nodes (3): config, middleware(), updateSession()

### Community 8 - "Streak Tracking Calendar"
Cohesion: 0.10
Nodes (22): StreakBadge, StreakBadgeProps, streakBadgeVariants, StreakResponse, didUseFreezeOnDate(), formatDateKey(), getDateKey(), getGitCells() (+14 more)

### Community 9 - "Shared Component Constants"
Cohesion: 0.09
Nodes (21): aliases, components, hooks, lib, ui, utils, iconLibrary, menuAccent (+13 more)

### Community 10 - "TypeScript Compiler Config"
Cohesion: 0.10
Nodes (20): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+12 more)

### Community 11 - "Leaderboard Podium UI"
Cohesion: 0.06
Nodes (29): LeaderboardCard, LeaderboardCardProps, LeaderboardRunOption, LeaderboardPodium, LeaderboardPodiumProps, LeaderboardRanking, PODIUM_CONFIG, podiumVariants (+21 more)

### Community 12 - "Points Awards System"
Cohesion: 0.13
Nodes (9): PointsAward, PointsAwards, PointsAwardsProps, PointsAwardTrigger, TooltipContent, triggerIconMap, PointsBadge, PointsBadgeProps (+1 more)

### Community 13 - "Typography & Layout Ribbons"
Cohesion: 0.20
Nodes (8): cormorant, dmSans, jetbrainsMono, syne, metadata, Ribbons(), RibbonsProps, Toaster()

### Community 14 - "Crew Navigation Maps"
Cohesion: 0.29
Nodes (4): defaultIcon, RouteMapProps, SECTOR_COORDINATES, vehicleIcon

### Community 15 - "Agent Rules & Configuration"
Cohesion: 0.50
Nodes (3): Next.js Agent Rules, CLAUDE.md Documentation, nextConfig

### Community 16 - "Project README Documentation"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

### Community 17 - "Planning Metadata Config"
Cohesion: 0.08
Nodes (25): dependencies, clsx, motion, next, react, react-dom, tailwind-merge, @tailwindcss/cli (+17 more)

### Community 20 - "Graphify Rule System"
Cohesion: 0.47
Nodes (5): compute_moving_averages(), latest_trends(), DataFrame, Model 3 - Moving Average (trend) computed per (Region, Material) series.  Produc, Most-recent SMA/vol per (Region, Material), mapped to app taxonomy.

### Community 26 - "Community 26"
Cohesion: 0.50
Nodes (4): build(), DataFrame, Bridge the granular model to the Trashium app taxonomy.  Steps:   1. Predict pay, to_sql()

### Community 27 - "Community 27"
Cohesion: 0.40
Nodes (4): How it maps to the app, Run the pipeline, Setup, Trashium Pricing ML

### Community 28 - "Community 28"
Cohesion: 0.40
Nodes (3): homeIcon, TrackingMapProps, truckIcon

### Community 29 - "Community 29"
Cohesion: 0.67
Nodes (3): main(), Train and evaluate the three pricing models on the historical dataset.    Model, _scores()

### Community 32 - "Community 32"
Cohesion: 0.10
Nodes (19): compilerOptions, allowJs, esModuleInterop, incremental, isolatedModules, jsx, lib, module (+11 more)

### Community 33 - "Community 33"
Cohesion: 0.09
Nodes (25): getSectorRankings, normalizeSectorName(), OPERATIONAL_SECTORS, DashboardContent(), getSectorRankings, getStreakPeriods(), handleLogWasteSegregation, handleSubmitQuiz (+17 more)

### Community 34 - "Community 34"
Cohesion: 0.29
Nodes (5): getDisplayWeight(), getDisplayWeight(), RecentPickupsProps, TRASHIUM_PICKUP_SLOTS, StatusBadge()

### Community 35 - "Community 35"
Cohesion: 0.40
Nodes (3): geistMono, geistSans, metadata

### Community 36 - "Community 36"
Cohesion: 0.50
Nodes (3): Deploy on Vercel, Getting Started, Learn More

## Knowledge Gaps
- **241 isolated node(s):** `wasteTypes`, `areas`, `metadata`, `CrewRouteMap`, `PickupRequest` (+236 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **10 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `cn()` connect `Admin Hub Dashboard` to `Community 33`, `Crew Hub Operations`, `Metrics & Impact Counters`, `Achievements UI System`, `Streak Tracking Calendar`, `Leaderboard Podium UI`, `Points Awards System`?**
  _High betweenness centrality (0.137) - this node is a cross-community bridge._
- **Why does `createClient()` connect `Crew Hub Operations` to `Admin Hub Dashboard`, `Community 33`, `Metrics & Impact Counters`?**
  _High betweenness centrality (0.035) - this node is a cross-community bridge._
- **Why does `createClient()` connect `Metrics & Impact Counters` to `Crew Hub Operations`, `App Routing & Pages`, `Points Boost System`?**
  _High betweenness centrality (0.027) - this node is a cross-community bridge._
- **Are the 2 inferred relationships involving `createClient()` (e.g. with `createClient()` and `updateSession()`) actually correct?**
  _`createClient()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `wasteTypes`, `areas`, `metadata` to the rest of the system?**
  _251 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Admin Hub Dashboard` be split into smaller, more focused modules?**
  _Cohesion score 0.07407407407407407 - nodes in this community are weakly interconnected._
- **Should `Crew Hub Operations` be split into smaller, more focused modules?**
  _Cohesion score 0.07402031930333818 - nodes in this community are weakly interconnected._